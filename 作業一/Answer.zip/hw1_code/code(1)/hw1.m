clc;
clear;
train_path = './plant-seedlings-classification/train';
test_path = './plant-seedlings-classification/test';

d = dir(train_path);
n_classes = length(d) - 2;
train_x = [];
valid_x = [];
train_y = [];
valid_y = [];

% load train images
for i = 3:length(d)
    f = fullfile(train_path, d(i).name);
    img_name = dir(strcat(f, '\*.png'));
    % half = length(img_name) / 2;
    bbb = length(img_name);
    half = bbb / 2;
    disp('load train dir:');
    disp(i-2);
    for j = 1:bbb
        img_path = fullfile(f,img_name(j).name);
        img = imread(img_path);
        img = imresize(img, [224,224]);
        img = reshape(img,1,[]);
        if j < half
            train_x = [[train_x]; [img]];
            train_y = [[train_y]; [(i-2)]];
        else
            valid_x = [[valid_x]; [img]];
            valid_y = [[valid_y]; [(i-2)]];
        end
    end
end
disp('load train images completed.');
% for train
sad_raw = eye(length(train_y));
sad_raw = sad_raw .* 999999999;
sad_his = eye(length(train_y));
sad_his = sad_his .* 999999999;
sad_lbp = eye(length(train_y));
sad_lbp = sad_lbp .* 999999999;
sad_hog = eye(length(train_y));
sad_hog = sad_hog .* 999999999;
sad_gab = eye(length(train_y));
sad_gab = sad_gab .* 999999999;
sad_coo = eye(length(train_y));
sad_coo = sad_coo .* 999999999;
sad_bag = eye(length(train_y));
sad_bag = sad_bag .* 999999999;
wavelength = 4;
orientation = 90;
% imds = imageDatastore(train_path,'IncludeSubfolders',true,'LabelSource','foldernames');
% tbl = countEachLabel(imds);
% [trainingSet, validationSet] = splitEachLabel(imds, 0.6, 'randomize');
% bag = bagOfFeatures(trainingSet);
for i = 1:(length(train_y)-1)
    img1 = train_x(i,:);
    img1 = reshape(img1,224,224,3);
    img1_gray = rgb2gray(img1);
    [x, r1, g1, b1] = color_histogram(img1);
    f1_lbp = extractLBPFeatures(img1_gray);
    f1_hog = extractHOGFeatures(img1);
    [mag1,phase] = imgaborfilt(img1_gray,wavelength,orientation);
    glcm1 = graycomatrix(img1_gray,'Offset',[2 0]);
    for j = (i+1):length(train_y)
        img2 = train_x(j,:);
        img2 = reshape(img2,224,224,3);
        img2_gray = rgb2gray(img2);
        % raw
        res_raw = abs(img1 - img2);
        res_raw = sum(res_raw(:));
        sad_raw(i,j) = res_raw;
        sad_raw(j,i) = res_raw;
        % lbp       
        f2_lbp = extractLBPFeatures(img2_gray);
        res_lbp = sum(abs(f1_lbp - f2_lbp));
        sad_lbp(i,j) = res_lbp;
        sad_lbp(j,i) = res_lbp;
        % color histogram
        [x, r2, g2, b2] = color_histogram(img2);
        res_his = sum(abs(r1-r2) + abs(g1-g2) + abs(b1-b2)) / 3;
        sad_his(i,j) = res_his;
        sad_his(j,i) = res_his;
        % hog
        f2_hog = extractHOGFeatures(img2);
        res_hog = sum(abs(f1_hog - f2_hog));
        sad_hog(i,j) = res_hog;
        sad_hog(j,i) = res_hog;
        % gabor filter        
        [mag2,phase] = imgaborfilt(img2_gray,wavelength,orientation);
        res_gab = abs(mag1 - mag2);
        res_gab = sum(res_gab(:));
        sad_gab(i,j) = res_gab;
        sad_gab(j,i) = res_gab;
        % co-occurrence matrix        
        glcm2 = graycomatrix(img2_gray,'Offset',[2 0]);
        res_coo = abs(glcm1 - glcm2);
        res_coo = sum(res_coo(:));
        sad_coo(i,j) = res_coo;
        sad_coo(j,i) = res_coo;
%         % bag of feature
%         img1 = readimage(imds, i);
%         img2 = readimage(imds, j);
%         f1_bag = encode(bag, img1);
%         f2_bag = encode(bag, img2);
%         res_bag = sum(abs(f1_bag - f2_bag));
%         sad_bag(i,j) = res_bag;
%         sad_bag(j,i) = res_bag;
    end 
end

% train acc of raw
[m,n] = min(sad_raw);
n = reshape(train_y(n),[],1);
n_corect = length(find(n == train_y));
train_acc_raw = n_corect / length(train_y);
disp(['train acc of raw : ' num2str(train_acc_raw)]);

% train acc of color histogram
[m,n] = min(sad_his);
n = reshape(train_y(n),[],1);
n_corect = length(find(n == train_y));
acc_his = n_corect / length(train_y);
disp(['train acc of his : ' num2str(acc_his)]);

% train acc of lbp
[m,n] = min(sad_lbp);
n = reshape(train_y(n),[],1);
n_corect = length(find(n == train_y));
acc_lbp = n_corect / length(train_y);
disp(['train acc of lbp : ' num2str(acc_lbp)] );

% train acc of hog
[m,n] = min(sad_hog);
n = reshape(train_y(n),[],1);
n_corect = length(find(n == train_y));
train_acc_hog = n_corect / length(train_y);
disp(['train acc of hog : ' num2str(train_acc_hog)] );

% train acc of gabor filter
[m,n] = min(sad_gab);
n = reshape(train_y(n),[],1);
n_corect = length(find(n == train_y));
train_acc_gab = n_corect / length(train_y);
disp(['train acc of gab : ' num2str(train_acc_gab)] );

% train acc of co-occurrence
[m,n] = min(sad_coo);
n = reshape(train_y(n),[],1);
n_corect = length(find(n == train_y));
train_acc_coo = n_corect / length(train_y);
disp(['train acc of coo : ' num2str(train_acc_coo)] );

% % train acc of bag of feature
% [m,n] = min(sad_bag);
% n = reshape(train_y(n),[],1);
% n_corect = length(find(n == train_y));
% train_acc_bag = n_corect / length(train_y);
% disp(['train acc of bag : ' num2str(train_acc_bag)] );



for i = 1:(length(valid_y)-1)
    img1 = valid_x(i,:);
    img1 = reshape(img1,224,224,3);
    img1_gray = rgb2gray(img1);
    [x, r1, g1, b1] = color_histogram(img1);
    f1_lbp = extractLBPFeatures(img1_gray);
    f1_hog = extractHOGFeatures(img1);
    [mag1,phase] = imgaborfilt(img1_gray,wavelength,orientation);
    glcm1 = graycomatrix(img1_gray,'Offset',[2 0]);
    for j = (i+1):length(valid_y)
        img2 = valid_x(j,:);
        img2 = reshape(img2,224,224,3);
        img2_gray = rgb2gray(img2);
        % raw
        res_raw = abs(img1 - img2);
        res_raw = sum(res_raw(:));
        sad_raw(i,j) = res_raw;
        sad_raw(j,i) = res_raw;
        % lbp
        f2_lbp = extractLBPFeatures(img2_gray);
        res_lbp = sum(abs(f1_lbp - f2_lbp));
        sad_lbp(i,j) = res_lbp;
        sad_lbp(j,i) = res_lbp;
        % color histogram
        [x, r2, g2, b2] = color_histogram(img2);
        res_his = sum(abs(r1-r2) + abs(g1-g2) + abs(b1-b2)) / 3;
        sad_his(i,j) = res_his;
        sad_his(j,i) = res_his;
        % hog
        f2_hog = extractHOGFeatures(img2);
        res_hog = sum(abs(f1_hog - f2_hog));
        sad_hog(i,j) = res_hog;
        sad_hog(j,i) = res_hog;
        % gabor filter
        [mag2,phase] = imgaborfilt(img2_gray,wavelength,orientation);
        res_gab = abs(mag1 - mag2);
        res_gab = sum(res_gab(:));
        sad_gab(i,j) = res_gab;
        sad_gab(j,i) = res_gab;
        % co-occurrence matrix
        glcm2 = graycomatrix(img2_gray,'Offset',[2 0]);
        res_coo = abs(glcm1 - glcm2);
        res_coo = sum(res_coo(:));
        sad_coo(i,j) = res_coo;
        sad_coo(j,i) = res_coo;
        % bag of feature   
%        img1 = readimage(imds, i);
%        img2 = readimage(imds, j);
%        f1_bag = encode(bag, img1);
%        f2_bag = encode(bag, img2);
%        res_bag = sum(abs(f1_bag - f2_bag));
%        sad_bag(i,j) = res_bag;
%        sad_bag(j,i) = res_bag;
        
    end 
    if mod(i,10) == 0
        disp('valid done :');
        disp(i);
    end
end

% valid acc of raw
[m,n] = min(sad_raw);
n = reshape(valid_y(n),[],1);
n_corect = length(find(n == valid_y));
valid_acc_raw = n_corect / length(valid_y);
disp(['valid acc of raw : ' num2str(valid_acc_raw)]);

% valid acc of color histogram
[m,n] = min(sad_his);
n = reshape(valid_y(n),[],1);
n_corect = length(find(n == valid_y));
valid_acc_his = n_corect / length(valid_y);
disp(['valid acc of his : ' num2str(valid_acc_his)]);

% valid acc of lbp
[m,n] = min(sad_lbp);
n = reshape(valid_y(n),[],1);
n_corect = length(find(n == valid_y));
valid_acc_lbp = n_corect / length(valid_y);
disp(['valid acc of lbp : ' num2str(valid_acc_lbp)] );

% valid acc of hog
[m,n] = min(sad_hog);
n = reshape(valid_y(n),[],1);
n_corect = length(find(n == valid_y));
valid_acc_hog = n_corect / length(valid_y);
disp(['valid acc of hog : ' num2str(valid_acc_hog)] );

% valid acc of gabor filter
[m,n] = min(sad_gab);
n = reshape(valid_y(n),[],1);
n_corect = length(find(n == valid_y));
valid_acc_gab = n_corect / length(valid_y);
disp(['valid acc of gab : ' num2str(valid_acc_gab)] );

% valid acc of co-occurrence
[m,n] = min(sad_coo);
n = reshape(valid_y(n),[],1);
n_corect = length(find(n == valid_y));
valid_acc_coo = n_corect / length(valid_y);
disp(['valid acc of coo : ' num2str(valid_acc_coo)] );

% % valid acc of bag of feature
% [m,n] = min(sad_bag);
% n = reshape(valid_y(n),[],1);
% n_corect = length(find(n == valid_y));
% valid_acc_bag = n_corect / length(valid_y);
% disp(['valid acc of bag : ' num2str(valid_acc_bag)] );

% load test images
test_img = dir(strcat(test_path, '\*.png'));
aaa = length(test_img);
% aaa = 10;
img_name = [];
test_x = [];
for i = 1:aaa
    f = fullfile(test_path, test_img(i).name);
    img_name = [img_name; test_img(i).name];
    img_path = f;
    img = imread(img_path);
    img = imresize(img, [224,224]);
    img = reshape(img,1,[]);
    test_x = [[test_x]; [img]];
    if mod(i,100) == 0
        disp('load test images:');
        disp(i);
    end
end
disp('load test images completed.');

% for test
train_x = [train_x; valid_x];
train_y = [train_y; valid_y];
sad_raw = zeros(length(train_y),aaa);
sad_his = zeros(length(train_y),aaa);
sad_lbp = zeros(length(train_y),aaa);
sad_hog = zeros(length(train_y),aaa);
sad_gab = zeros(length(train_y),aaa);
sad_coo = zeros(length(train_y),aaa);
sad_bag = zeros(length(train_y),aaa);
for i = 1:aaa
    img1 = test_x(i,:);
    img1 = reshape(img1,224,224,3);
    img1_gray = rgb2gray(img1);
    [x, r1, g1, b1] = color_histogram(img1);
    f1_lbp = extractLBPFeatures(img1_gray);
    f1_hog = extractHOGFeatures(img1);
    [mag1,phase] = imgaborfilt(img1_gray,wavelength,orientation);
    glcm1 = graycomatrix(img1_gray,'Offset',[2 0]);
    for j = 1:length(train_y)
        img2 = train_x(j,:);
        img2 = reshape(img2,224,224,3);
        img2_gray = rgb2gray(img2);
        % raw
        res_raw = abs(img1 - img2);
        res_raw = sum(res_raw(:));
        sad_raw(j,i) = res_raw;
        % lbp       
        f2_lbp = extractLBPFeatures(img2_gray);
        res_lbp = sum(abs(f1_lbp - f2_lbp));
        sad_lbp(j,i) = res_lbp;
        % color histogram
        [x, r2, g2, b2] = color_histogram(img2);
        res_his = sum(abs(r1-r2) + abs(g1-g2) + abs(b1-b2)) / 3;
        sad_his(j,i) = res_his;
        % hog
        f2_hog = extractHOGFeatures(img2);
        res_hog = sum(abs(f1_hog - f2_hog));
        sad_hog(j,i) = res_hog;
        % gabor filter        
        [mag2,phase] = imgaborfilt(img2_gray,wavelength,orientation);
        res_gab = abs(mag1 - mag2);
        res_gab = sum(res_gab(:));
        sad_gab(j,i) = res_gab;
        % co-occurrence matrix        
        glcm2 = graycomatrix(img2_gray,'Offset',[2 0]);
        res_coo = abs(glcm1 - glcm2);
        res_coo = sum(res_coo(:));
        sad_coo(j,i) = res_coo;
    end
    if mod(i,10) == 0
            disp('test done :');
            disp(i);
    end
end

class_name = ["Black-grass","Charlock","Cleavers","Common Chickweed","Common wheat","Fat Hen","Loose Silky-bent","Maize","Scentless Mayweed","Shepherds Purse","Small-flowered Cranesbill","Sugar beet"];

% test result of raw
[m,n] = min(sad_raw);
n = reshape(n,[],1);
test_y = train_y(n);
fid = fopen('./res/raw.csv', 'wt');
fprintf(fid, 'file,species\n');
for i = 1:aaa
    fprintf(fid, '%s,%s\n', string(img_name(i,:)), string(class_name(test_y(i))) );
end
fclose(fid);

% test result of color histogram
[m,n] = min(sad_his);
n = reshape(n,[],1);
test_y = train_y(n);
fid = fopen('./res/his.csv', 'wt');
fprintf(fid, 'file,species\n');
for i = 1:aaa
    fprintf(fid, '%s,%s\n', string(img_name(i,:)), string(class_name(test_y(i))) );
end
fclose(fid);
disp('test of his done!');

% test result of lbp
[m,n] = min(sad_lbp);
n = reshape(n,[],1);
test_y = train_y(n);
fid = fopen('./res/lbp.csv', 'wt');
fprintf(fid, 'file,species\n');
for i = 1:aaa
    fprintf(fid, '%s,%s\n', string(img_name(i,:)), string(class_name(test_y(i))) );
end
fclose(fid);
disp('test of lbp done!');

% test result of hog
[m,n] = min(sad_hog);
n = reshape(n,[],1);
test_y = train_y(n);
fid = fopen('./res/hog.csv', 'wt');
fprintf(fid, 'file,species\n');
for i = 1:aaa
    fprintf(fid, '%s,%s\n', string(img_name(i,:)), string(class_name(test_y(i))) );
end
fclose(fid);
disp('test of hog done!');

% train res of gabor filter
[m,n] = min(sad_gab);
n = reshape(n,[],1);
test_y = train_y(n);
fid = fopen('./res/gab.csv', 'wt');
fprintf(fid, 'file,species\n');
for i = 1:aaa
    fprintf(fid, '%s,%s\n', string(img_name(i,:)), string(class_name(test_y(i))) );
end
fclose(fid);
disp('test of gab done!');

% test result of co-occurrence
[m,n] = min(sad_coo);
n = reshape(n,[],1);
test_y = train_y(n);
fid = fopen('./res/coo.csv', 'wt');
fprintf(fid, 'file,species\n');
for i = 1:aaa
    fprintf(fid, '%s,%s\n', string(img_name(i,:)), string(class_name(test_y(i))) );
end
fclose(fid);
disp('test of coo done!');